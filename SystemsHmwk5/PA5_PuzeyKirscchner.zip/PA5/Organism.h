/*
 * Organism.h
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#ifndef ORGANISM_H_
#define ORGANISM_H_

class Organism {
public:
	char ID;
	Organism();
	virtual ~Organism();
	virtual void move(Organism*** gridSpace, int x, int y, int size);
	char* emptySpaces(Organism*** gridSpace, int x, int y, int size);
	bool checked;
	void breed(Organism*** gridSpace, int x, int y, int size);
	int breedTime;
	int numMoves;
};

#endif /* ORGANISM_H_ */
