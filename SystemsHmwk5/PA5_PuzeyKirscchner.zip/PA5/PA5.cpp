/*
 * PA5.cpp
 *
 *  Created on: Feb 21, 2018
 *      Author: lpuzey
 */

#include "PA5.h"
#include "Board.h"
#include "Doodlebug.h"
#include "Ant.h"
#include <iostream>
#include <cstdlib>

int main(int argc, char **argv){

	std::cout <<"Ant and Doodlebug Simulation\n";

	int gridSize = 20;    //number of customers being served
	int doodlebugs = 5;        // number of tellers in bank
	int ants = 100;    //length of simulation
	int time_steps = 1000;    // average time for teller and customer to complete service
	int seed = 1;    //seed for randomly generated values
	int pause; //indication as to whether to pause. Blank or zero meansdon't pause.

	// catches errors in program input
	if ((argc < 5) || (argc > 7)) {
		//prints correct usage
		std::cout << "Usage:\n";
		std::cout << "   ./PA5 gridSize #doodlebugs #ants #time_steps [seed] pause" << std::endl;
		return EXIT_FAILURE;
	}

	// checks for valid input
	if ( atoi(argv[1]) == 0 || atoi(argv[2]) == 0 || atoi(argv[3]) == 0 || atoi(argv[4]) == 0) {
		std::cout << "Invalid input" << std::endl;
		return EXIT_FAILURE;
	}

	// sets input
	gridSize = atoi(argv[1]);
	//   std::cout << "\tgridSize = " << gridSize << std::endl;

	doodlebugs = atoi(argv[2]);
	// std::cout << "\t# of doodle bugs = " <<doodlebugs << std::dendl;

	ants = atof(argv[3]);
	// std::cout << "\t# of ants = " <<ants << std::endl;

	time_steps = atof(argv[4]);
	// std::cout << "\t# of time steps to simulate = " <<time_steps <<std::endl;

	//determines if a seed is given
	if (argc >= 5) {
		//sets seed
		seed = atoi(argv[5]);
		// std::cout << "\tseed = " << seed << std::endl;
		srand(seed);
	}
	// otherwise default
	else srand(time(NULL));

	if(argc >= 7){
		pause = atoi(argv[6]);
		if(pause < 0){
			pause = 0;
		}
	}
	else {
		pause = 0;
	}
	std::cout << "\tpause = " <<pause << std::endl;

	//std::cout << "Initializing Board"<< std::endl;
	Board b (gridSize);
	b.populateAnts(ants);
	b.populateDoodlebugs(doodlebugs);

	//std::cout << "\tPopulating Ants"<< std::endl;
	//	b.populateAnts(ants);
	// std::cout << "\tPopulating Doodle bugs"<< std::endl;
	//b.populateDoodlebugs(doodlebugs);

	//std::cout << "Board"<< std::endl;
	// b.print();





	std::cout << std::endl << std::endl;
	b.print();
	b.playRound(time_steps,pause);
	b.print();



	std::cout << "End" << std::endl;
}
