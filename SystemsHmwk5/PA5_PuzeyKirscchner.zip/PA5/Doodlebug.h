/*
 * Doodlebug.h
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#ifndef DOODLEBUG_H_
#define DOODLEBUG_H_
#include"Organism.h"


class Doodlebug: public Organism  {
public:
	Doodlebug(int x,int y);
	virtual ~Doodlebug();
	char* Ants(Organism*** gridSpace, int x, int y, int size);
	void move(Organism*** gridSpace, int x, int y, int size);
	int counter;
	//char* emptySpaces(Organism*** gridSpace, int x, int y, int size);
	void breed(Organism*** gridSpace, int x, int y, int size);

};

#endif /* DOODLEBUG_H_ */
