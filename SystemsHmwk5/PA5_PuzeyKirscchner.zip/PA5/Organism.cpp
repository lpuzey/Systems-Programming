/*
 * Organism.cpp
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#include "Organism.h"
#include<iostream>
#include <cstdlib>

/**
 *
 */
Organism::Organism() {
	ID = ' ';
	checked = false;
	breedTime = -1;
	numMoves = 0;
}

/**
 *
 */
Organism::~Organism() {
	// TODO Auto-generated destructor stub
}

void Organism::move(Organism*** gridSpace, int x, int y, int size){
	//std::cout << "In organism move" << std::endl;
}

/**
 * @Param ***gridSpace current Board
 * @Param x x-coordinate
 * @Param y y-coordinate
 * @Param size size of board
 * @Return array of empty spaces
 */
char* Organism::emptySpaces(Organism*** gridSpace, int x, int y, int size){
	   //std::cout << "In empty spaces" << std::endl;
	     char *spaces;
	     // allocates array
	     spaces= (char*) malloc(6 * sizeof(char));

	     int count = 0; // counts number of ants for allocating array

	     // north
	     if ((y-1 >= 0) && (gridSpace[x][y-1] == NULL)) {
	         spaces[count++] = 'n';
	     }
	     // east
	     if ((x+1 < size) && (gridSpace[x+1][y] == NULL)) {
	         spaces[count++] = 'e';
	     }
	     // south
	     if ((y+1 < size) && (gridSpace[x][y+1] == NULL)) {
	         spaces[count++] = 's';
	     }
	     // west
	     if ((x-1 >= 0) && (gridSpace[x-1][y] == NULL)) {
	         spaces[count++] = 'w';
	     }
	     if(count == 0){
	    	 spaces[5]= '0';
	     }
	     else if( count == 1){
	    	 spaces[5]= '1';
	     }
	     else if( count == 2){
	     	    	 spaces[5]= '2';
	     	     }
	     else if( count == 3){
	     	    	 spaces[5]= '3';
	     	     }
	     else if( count == 4){
	     	    	 spaces[5]= '4';
	     	     }
	    // std::cout << "Empty space count " << count << std::endl;
	     while(count<5){
	       spaces[count++] = '\0';
	     }
	     //std::cout << "spaces " << spaces << std::endl;

	     return spaces;
}

void Organism::breed(Organism*** gridSpace, int x, int y, int size){


}


