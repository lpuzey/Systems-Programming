/*
 * Ant.h
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#ifndef ANT_H_
#define ANT_H_
#include "Organism.h"



class Ant: public Organism {
public:
	Ant(int x,int y);
	int locationX;
	int locationY;
	virtual ~Ant();
	void move(Organism*** gridSpace, int x, int y, int size);
	void breed(Organism*** gridSpace, int x, int y, int size);
};

#endif /* ANT_H_ */
