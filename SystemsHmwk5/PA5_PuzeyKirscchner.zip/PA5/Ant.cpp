/*
 * Ant.cpp
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#include "Ant.h"
#include <cstdlib>
#include <iostream>

/**
 * @Param x x-coordinate
 * @Param y y-coordinate
 */
Ant::Ant(int x,int y) {
	ID = 'o'; // o indicates ant
	locationX = x; // x-coordinate
	locationY = y; // y-coordinate
	numMoves = 0; // counter for breeding
	breedTime = 3;

}

/**
 *
 */
Ant::~Ant() {
	// TODO Auto-generated destructor stub
}

/**
 * @Param *aBoard the current Board
 * @Param x x-coordinate
 * @Param y y-coordinate
 * @Param size sized of board
 */
void Ant::move(Organism*** gridSpace, int x, int y, int size){
	//std::cout << "Ants Move" << std::endl;

	if(checked == false){
		checked = true;
	//array containing empty cells
	char *emptySpace = emptySpaces(gridSpace, x, y, size);
	int asize = emptySpace[5]-'0';
	//std::cout << "asise " <<asize << std::endl;
	// randomly selects an empty cell
	if(asize > 0){
	int selection = (rand() % asize);

	// finds the correct empty cell
	if (emptySpace[selection] == 'n') {
		gridSpace[x][y-1] = this; // moves the ant
		gridSpace[x][y] = NULL; // blanks the old cell
	}
	else if (emptySpace[selection] == 'e') {
		gridSpace[x+1][y] = this;// moves the ant
		gridSpace[x][y] = NULL; // blanks the old cell
	}
	else if (emptySpace[selection] == 's') {
		gridSpace[x][y+1] = this; // moves the ant
		gridSpace[x][y] = NULL; // blanks the old cell
	}
	else if (emptySpace[selection] == 'w') {
		gridSpace[x-1][y] = this; // moves the ant
		gridSpace[x][y] = NULL; // blanks the old cell
	}
	numMoves++; // increments breeding counter
		}
	}
}

/**
 * @Param *aBoard current board
 * @Param x x-coordinate
 * @Param y y-coordinate
 * @Param size size of board
 */
void Ant::breed(Organism*** gridSpace, int x, int y, int size){

	// creates array of empty spaces
	char *emptySpace = emptySpaces(gridSpace, x, y, size);
	int eSize = emptySpace[5]-'0';
	// checks breed criteria
	if ((numMoves >= breedTime) && (eSize > 0)) {
		std::cout << "Ant breeding" << x <<y <<std::endl;
		// selects random empty space
		int selection = (rand() % eSize);

		// north
		if (emptySpace[selection] == 'n') {
			gridSpace[x][y-1] = new Ant(x,(y-1));
		}
		// east
		else if (emptySpace[selection] == 'e') {
			gridSpace[x+1][y] = new Ant((x+1),y);
		}
		// south
		else if (emptySpace[selection] == 's') {
			gridSpace[x][y+1] = new Ant(x,(y+1));
		}
		// west
		else if (emptySpace[selection] == 'w') {
			gridSpace[x-1][y] = new Ant((x-1),y);
		}
	}
	numMoves = 0; // resets number of moves
}

