/*
 * Board.h
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#ifndef BOARD_H_
#define BOARD_H_
#include "Organism.h"


class Board {

public:
	Organism ***gridSpace;
	int gridSize;

//	struct coordinates{int x; int y;};

	void populateDoodlebugs(int doodlebugs);
	void populateAnts(int ants);
	Board(int size);
	virtual ~Board();
	void print();
	void playRound(int rounds,int pause);


};

#endif /* BOARD_H_ */
