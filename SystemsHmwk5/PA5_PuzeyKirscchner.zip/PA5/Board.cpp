/*
  * Board.cpp
  *
  *  Created on: Feb 24, 2018
  *      Author: lpuzey
  */
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include "Doodlebug.h"
#include "Ant.h"
#include "Board.h"


Board::Board(int size) {
   gridSize = size;
   gridSpace= new Organism** [size];
   for(int xCounter=0;xCounter<size;xCounter++){
     gridSpace[xCounter] = new Organism* [size];
   }
}


Board::~Board() { }

void Board::populateAnts(int ants){
     int x;
     int y;
     for (int antCounter = 0; antCounter < ants; antCounter++){
       do{
         x = rand() % this->gridSize;
         y = rand() % this->gridSize;
       } while (gridSpace[x][y] != NULL);
       this->gridSpace[x][y] = new Ant(x,y);
     }
}

void Board::populateDoodlebugs(int doodlebugs){
     int x;
     int y;
     for (int doodleCounter = 0; doodleCounter < doodlebugs;
doodleCounter++){
       do{
         x = rand() % this->gridSize;
         y = rand() % this->gridSize;
       } while (gridSpace[x][y] != NULL);
       this->gridSpace[x][y] = new Doodlebug(x,y);
     }
}

void Board::print(){
   for(int x = 0; x<gridSize;x++){
     for(int y=0;y<gridSize;y++){
       if(gridSpace[x][y] != NULL){
     std::cout << " " << gridSpace[x][y]->ID << " ";
       }else{
     std::cout << " . ";
       }
     }
     std::cout << std::endl;
   }
}

void Board::playRound(int rounds,int pause){
	int round;
	int maxDoodlebugs = 0;
	int maxAnts = 0;
	for(round=1;round<=rounds;round++){
		int doodlebugCount = 0;
	for (int i = 0; i < gridSize; i++) {
		for (int j = 0; j < gridSize; j++) {
		if(!(gridSpace[i][j]== NULL)){
			if (gridSpace[i][j]->ID == 'x') {
				doodlebugCount++;

				gridSpace[i][j]->move(gridSpace,i,j,gridSize);
			}
			else if (gridSpace[i][j]-> ID == 'o'){
				gridSpace[i][j]-> checked = false; //clear ant for next round
			}
		}
	}
}
if(doodlebugCount > maxDoodlebugs){
	maxDoodlebugs = doodlebugCount;
}


	int antCount = 0;
	for (int i = 0; i < gridSize; i++) {
			for (int j = 0; j < gridSize; j++) {
				if(!(gridSpace[i][j]== NULL)){
					if (gridSpace[i][j]->ID =='o') {
					antCount++;
					gridSpace[i][j]->move(gridSpace,i,j,gridSize);
				}
				else if (gridSpace[i][j]-> ID == 'x'){
					gridSpace[i][j]-> checked = false; //clear ant for next round
				}
			}
		}
	}
	if(antCount > maxAnts){
		maxAnts = antCount;
	}
	for (int i = 0; i < gridSize; i++) {
		for (int j = 0; j < gridSize; j++) {
			if(!(gridSpace[i][j]== NULL)){
				//std::cout << "calling breed" << i <<j <<std::endl;
				gridSpace[i][j]->breed(gridSpace,i,j,gridSize);

			}
		}
	}
	if((pause > 0)&&(round > 0)&&(round%pause == 0)){
		std::cout << "round:" << round<<  std::endl;
		print();
		std::cout<<"Press enter to continue:"<<std::endl;
		getchar();
		}

	if(doodlebugCount == 0){
		std::cout << "rounds executed:" << round<<  std::endl;
		std::cout << "All doodlebugs dead" << std::endl;
		std::cout << "Total number of Doodlebugs:" << maxDoodlebugs<<std::endl;
		std::cout << "Total number of Ants:" << maxAnts<<std::endl;
		return;
		}
	if(antCount==0){
			std::cout << "rounds executed:" << round<<  std::endl;
			std::cout << "All ants dead" << std::endl;
			std::cout << "Total number of Doodlebugs:" << maxDoodlebugs<<std::endl;
			std::cout << "Total number of Ants:" << maxAnts<<std::endl;
			return;
			}
		}
	std::cout << "Total number of Doodlebugs:" << maxDoodlebugs<<std::endl;
	std::cout << "Total number of Ants:" << maxAnts<<std::endl;
	std::cout << "Sucessfully executed rounds: " << rounds<<std::endl;
}
