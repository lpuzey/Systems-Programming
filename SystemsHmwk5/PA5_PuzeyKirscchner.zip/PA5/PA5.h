/*
 * PA5.h
 *
 *  Created on: Feb 21, 2018
 *      Author: lpuzey
 */

#ifndef PA5_H_
#define PA5_H_

class PA5 {
public:
	PA5();
	virtual ~PA5();
};

#endif /* PA5_H_ */
