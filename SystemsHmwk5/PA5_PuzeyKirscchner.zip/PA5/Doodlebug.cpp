/*
 * Doodlebug.cpp
 *
 *  Created on: Feb 24, 2018
 *      Author: lpuzey
 */

#include "Doodlebug.h"
#include<iostream>
#include <cstdlib>

/**
 * @Param x x-coordinate
 * @Param y y-coordinate
 * @Param *world the board
 */
Doodlebug::Doodlebug(int x,int y) {
	ID = 'x';
	counter = 0;
	breedTime = 8;
}

/**
 *
 */
Doodlebug::~Doodlebug() {
	// TODO Auto-generated destructor stub
}

/**
 *
 */
char* Doodlebug::Ants(Organism*** gridSpace, int x, int y, int size) {
   //std::cout << "In doodlebug Ants" << std::endl;
     char *Ants;
     // allocates array
     Ants = (char*) malloc(6 * sizeof(char));

     int count = 0; // counts number of ants for allocating array

     // north
     if ((y-1 >= 0) && (gridSpace[x][y-1] != NULL) &&
(gridSpace[x][y-1]->ID == 'o')) {
         Ants[count++] = 'n';
     }
     // east
     if ((x+1 < size) && (gridSpace[x+1][y] != NULL) &&
(gridSpace[x+1][y]->ID == 'o')) {
         Ants[count++] = 'e';
     }
     // south
     if ((y+1 < size) && (gridSpace[x][y+1] != NULL) &&
(gridSpace[x][y+1]->ID == 'o')) {
         Ants[count++] = 's';
     }
     // west
     if ((x-1 >= 0) && (gridSpace[x-1][y] != NULL) &&
(gridSpace[x-1][y]->ID == 'o')) {
         Ants[count++] = 'w';
     }

     Ants[5] = count;
     //std::cout << "count " << count << std::endl;
     while(count<5){
       Ants[count++] = '\0';
     }
     //std::cout << "ants " << Ants << std::endl;

     return Ants;
}


void Doodlebug::move(Organism*** gridSpace, int x, int y, int size) {
   //std::cout << "In doodlebug move" << std::endl;

   if (checked ==false){
	   checked = true;
     char* ants = Ants(gridSpace, x, y, size);
     int asize = ants[5];
     //std::cout << "ants " << ants << " " << asize << std::endl;

     if (counter >= 3) {
       //std::cout << "starvation " << x << " " << y << std::endl;
         gridSpace[x][y] = NULL;
     }
     // eats an ant
     else if (asize > 0) {
    	 numMoves++;
         int selection = rand() % asize;

     		// north
     		if (ants[selection] == 'n') {
     			gridSpace[x][y-1] = this;
     			gridSpace[x][y] = NULL;
     		}
     		// east
     		else if (ants[selection] == 'e') {
     			gridSpace[x+1][y] = this;
     			gridSpace[x][y] = NULL;
     		}
     		// south
     		else if (ants[selection] == 's') {
     			gridSpace[x][y+1] = this;
     			gridSpace[x][y] = NULL;
     		}
     		// west
     		else if (ants[selection] == 'w') {
     			gridSpace[x-1][y] = this;
     			gridSpace[x][y] = NULL;
     		}
     	}
     	else {
     		char *emptySpace = emptySpaces(gridSpace, x, y, size);
     		int esize = emptySpace[5]-'0';
     		// randomly selects an empty cell
     		int selection = rand() % esize;

     		// finds the correct empty cell
     		if (emptySpace[selection] == 'n') {
     			gridSpace[x][y-1] = this; // moves the ant
     			gridSpace[x][y] = NULL; // blanks the old cell
     		}
     		else if (emptySpace[selection] == 'e') {
     			gridSpace[x+1][y] = this;// moves the ant
     			gridSpace[x][y] = NULL; // blanks the old cell
     		}
     		else if (emptySpace[selection] == 's') {
     			gridSpace[x][y+1] = this; // moves the ant
     			gridSpace[x][y] = NULL; // blanks the old cell
     		}
     		else if (emptySpace[selection] == 'w') {
     			gridSpace[x-1][y] = this; // moves the ant
     			gridSpace[x][y] = NULL; // blanks the old cell
     		}
     		counter++;
     	}
   }
 }

void Doodlebug::breed(Organism*** gridSpace, int x, int y, int size){

	// creates array of empty spaces
	char *emptySpace = emptySpaces(gridSpace, x, y, size);
	int eSize = emptySpace[5]-'0';
	// checks breed criteria
	if ((numMoves >= breedTime) && (eSize > 0)) {

		// selects random empty space
		int selection = (rand() % eSize);

		// north
		if (emptySpace[selection] == 'n') {
			gridSpace[x][y-1] = new Doodlebug(x,(y-1));
		}
		// east
		else if (emptySpace[selection] == 'e') {
			gridSpace[x+1][y] = new Doodlebug((x+1),y);
		}
		// south
		else if (emptySpace[selection] == 's') {
			gridSpace[x][y+1] = new Doodlebug(x,(y+1));
		}
		// west
		else if (emptySpace[selection] == 'w') {
			gridSpace[x-1][y] = new Doodlebug((x-1),y);
		}
	}
	numMoves = 0; // resets number of moves
}
