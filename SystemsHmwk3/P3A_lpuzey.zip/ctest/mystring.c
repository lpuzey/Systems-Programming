/** mystring.c
 * @author Mike Ciaraldi
 * My own versions of some of the C-style string functions
*/

#include <string.h>
#include <stdlib.h>
// Have to #include stdlib.h because it is needed to use malloc()
#include "mystring.h"

/** Duplicates a C-style string.
 @param src Pointer to string to be copied
 @return Pointer to freshly-allocated string containing a duplicate of src
         or null if no memory is available
*/
char* mystrdup1(const char* src) {
  int length; // Length of the source string
  char* newstr; // Pointer to memory which will hold new string

  length = strlen(src) + 1;  // Leave space for the terminator
  newstr = (char*) malloc(length); // Must cast!

  // If no memory was available, return null pointer immediately
  if (newstr == 0) return (char *) 0;

  // Otherwise, copy the string and return pointer to new string
  strcpy(newstr, src);
  return newstr;
}

/**
 *@param *str pointer to character array
 *@return length of str
 */

size_t mystrlen1(const char *str){
	size_t i=0;
	while (str[i] != 0)
		i++;

		return i;

}

/**
 *@param *str pointer to character array
 *@return length of str
 */

size_t mystrlen2(const char *str){
	const char *p = str;
	while(*str++ != '\0'){}
	return (str - p)-1;
}

/**
 *@param *dest pointer to character array
 *@param *src pointer to character array
 *@return copies the string from src to dest
 */
char *mystrcpy(char *dest, const char *src){
	char* result = dest;
	if(('\0' != dest)&& ('\0' != src)){
		while ('\0' != *src){
			*dest++ = *src++;
		}
		*dest = '\0';
	}
	return result;
}

/**
 *@param *dest pointer to character array
 *@param *src pointer to character array
 *@return concatenated string
 */
char *mystrcat(char *dest,const char *src){
	int i;
	int j;

	for(i=0; dest[i] != '\0'; i++); //dest[i] will not be equal to null terminator
	for(j=0; src[j] != '\0'; j++){ //src[j] will not be equal to the null terminator
		dest[i+j] = src[j];
	}
	dest[i+j] = '\0';
	return dest;
}

/**
 *@param *dest pointer to character array
 *@param *src pointer to character array
 *@param n specified size
 *@return concatenated string of n size
 */
char *mystrncat(char *dest, const char *src, size_t n){
	char *tempt = dest;
	int i;
	i=0;
	while(*dest){
		dest++;
	}
	while(i<n){
		*dest =*src;
		dest++;
		src++;
		i++;
	}
	*dest = '\0';
	return tempt;
}

/**
 *@param *dest pointer to character array
 *@param *src pointer to character array
 *@param n specified size
 *@return copies string of size n
 */
char *mystrncpy(char *dest, const char *src, size_t n){
	int i = 0;

	for(i = 0; i < n && src[i] != '\0'; i++)
		dest[i] = src[i];
	dest[i] = '\0';
	return dest;
}

/**
 *@param *str pointer to character array
 *@param n pecified size
 */
char *mystrndup(const char *str, size_t n){
	  int length;
	  char* newstr;
	  length = n + 1;
	  newstr = (char*) malloc(length);
	  if (newstr == 0) return (char *) 0;
	  strncpy(newstr, str,n);
	  return newstr;
}

