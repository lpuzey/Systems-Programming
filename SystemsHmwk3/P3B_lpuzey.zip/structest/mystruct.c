/** mystruct.c
 * @author Mike Ciaraldi
*/


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "mystruct.h"

/** Allocates an Employee struct and fills in its fields
 * @param birth Year the emploee was born.
 * @param start Year the employee started with the company.
 * @param name String containing employee's name
 * @return Pointer to Employee struct, newly allocated from the heap.
 */
struct Employee* makeEmployee(int birth, int start, const char *name) {
	struct Employee *new = (struct Employee*)malloc(sizeof(struct Employee));
	new->birth_year= birth;
	new->start_year= start;
	for(int i=0;i<strlen(name); i++){
			new->name[i]=name[i];
	}
	return new;
}

/**
 *@param *e pointer to a struct of employee
 *@return prints the inputed Employee sturct
 */
void printEmployee(struct Employee *e) {
	printf("Name: %s\n", e->name);
	printf("Birth Year: %d\n", e->birth_year);
	printf("Start Year: %d \n", e->start_year);
}

/**Generates a number between 0 and 2018
 * @return Int that is random
 */
int randomInt(){
	return rand()%2018;
}

/**Generates a random character from A-Z
 * @return Char that is random
 */
char randomChar(){
	char letters = 'A'+(rand()%26);
	return letters;
}

/**Allocates space for an array of char and then fill it with random chars
 * @return String that is random
 */
char* randomString(size_t n){
	char* word = malloc(n+1);
	int i;
	for(i=0; i<n; i++){
		word[i] = randomChar();
	}
	word[n]='\0';
	return word;
}

/**
 *@return makes a random employee using the previous functions
 */
struct Employee* makeRandomEmployee() {
	char* name;
	struct Employee *new = (struct Employee*)malloc(sizeof(struct Employee));
	new->birth_year= randomInt();
	new->start_year= randomInt();
	//strcpy(new -> name,randomString(10));
	name= randomString((rand()%20)+3);
	for(int i=0;i<strlen(name); i++){
			new->name[i]=name[i];
	}
	return new;
}

/**
 *@param count max size
 *@return puts random employee in array
 */
struct Employee** randomEmployees(int count){
	struct Employee** Employees = (struct Employee**)malloc(sizeof(struct Employee*)*count);
	int i;
	for(i=0; i< count;i++){
		Employees[i]= makeRandomEmployee();
		if(i==0){
			printf("%s\n",Employees[i]->name);
		}
	}
	return Employees;
}

/**
 *@param **e pointer to a point to a struct of Employees
 *@param count max size
 *@return prints the random employee struct values
 */
void printRandomEmployee(struct Employee **e, int count) {
	int i;
	for (i=0;i<count; i++){
		printEmployee(e[i]);
	}
}

/**Hellper function for my deep function
 *@param *src pointer to a struct of employees
 *@return new pointer filled with Employee values
 */

struct Employee* deepHelper(struct Employee* src) {
	struct Employee *new = (struct Employee*)malloc(sizeof(struct Employee));
	new->birth_year= src->birth_year;
	new->start_year= src->start_year;
	for(int i=0;i<strlen(src->name); i++){
			new->name[i]=src->name[i];
	}
	return new;
}

/**EXTRA CREDIT DEEP FUNTION
 *@param **e pointer to a pointer to a struct of Employees
 *@param elements specified elements in array
 *@return a deep duplicate of the struct
 */


struct Employee **employeeDup2(struct Employee **e, int elements){
	struct Employee **a;
	int i;
	a=(struct Employee**)malloc(elements * sizeof(struct Employee*));
	if(!a){
		return(struct Employee**)NULL;
	}
	for (i=0;i<elements;i++){
		a[i]= deepHelper(e[i]);
		}
		return a;
}


/**
 *@param **e pointer to a pointer to a struct of Employees
 *@return a clean copy of the struct
 */
void freeEmployee(struct Employee **e){
	free(e);
}
/** Shallow function
 *@param **e pointer to a pointer to a struct of Employees
 *@param elements specified elements in array
 *@return a shallow duplicate of the struct
 */
struct Employee **employeeDup(struct Employee **e, int elements){
	int i;
	struct Employee **p = (struct Employee**)malloc(sizeof(**e));
	for(i=0;i<=elements;i++){
		malloc(sizeof(**e));
		p[i]=e[i];
	}
	return p;
}

