/** mystruct.h
 * @author Mike Ciaraldi
 * Sample structs
*/

// Struct definition:

// Maximum number of characters in an employee name
#define MAX_NAME (99)

struct Employee {
	int birth_year; // Year the employee was born
	int start_year; // When employe started with the company.
	char name[MAX_NAME + 1];
};

// Function prototype(s):
struct Employee *makeEmployee(int birth, int start, const char* name);
void printEmployee(struct Employee *e);
int randomInt();
char randomChar();
char* randomString(size_t n);
struct Employee* makeRandomEmployee();
struct Employee** randomEmployees(int count);
void printRandomEmployee(struct Employee **e, int count);
struct Employee **employeeDup(struct Employee **e, int elements);
struct Employee **employeeDup2(struct Employee **e, int elements);
