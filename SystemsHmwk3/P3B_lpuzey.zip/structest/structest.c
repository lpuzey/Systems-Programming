#include <stdio.h>
#include "mystruct.h"

int main(int atgc, char *argv[]) {
	struct Employee *e;

	e = makeEmployee(1952, 1999, "Mike Ciaraldi");

	printEmployee(e);

	struct Employee** L = randomEmployees(10);
	struct Employee** Dup = employeeDup(L,10);
	struct Employee** Dup2= employeeDup2(L,10);

	printRandomEmployee(L,10);
	printRandomEmployee(Dup, 10);

	printf("Memory Addresses:\n");
	printf("%p\n",L[0]);
	printf("%p\n",Dup[0]);
	printf("%p",Dup2[0]);

	return 0;
}
