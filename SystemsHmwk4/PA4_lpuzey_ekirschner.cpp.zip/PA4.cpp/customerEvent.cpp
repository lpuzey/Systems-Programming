/*
 * customerEvent.cpp
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */
#include "Event.h"
#include "customerEvent.h"

#include <iostream>
#include <cstdlib>

/**customerEvent constructor
 * @Param arrivalTime time customer arrived at the bank
 */
customerEvent::customerEvent( float arrivalTime):Event(arrivalTime) {
	this->arrivalTime = arrivalTime;
}

/**customerEvent deconstructor
 *will delete anything in the constructor
 */
customerEvent::~customerEvent() {}

float customerEvent::action() {
	return this->arrivalTime;
}
