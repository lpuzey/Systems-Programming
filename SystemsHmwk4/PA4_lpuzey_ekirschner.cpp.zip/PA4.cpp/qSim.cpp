/*
 * qSim.cpp
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#include <iostream>
#include <cstdlib>

#include "Event.h"
#include "customerEvent.h"
#include "tellerEvent.h"
#include "eventQueue.h"

/**main function
 * @param argc Number of words on the command line.
 * @param argv Array of pointers to character strings containing the words on the command line.
 * @return 0 if success, 1 if invalid command line or unable to open file.
 */

int main(int argc, char **argv) {

	std::cout <<"Bank Simulation\n";

	int numCustomers;	//number of customers being served
	int numTellers;		// number of tellers in bank
	int simulationTime;	//length of simulation
	float avgServiceTime;	// average time for teller and customer to complete service
	int seed;	//seed for randomly generated values
	float bankTime = 0;

	// catches errors in program input
	if ((argc < 5) || (argc > 6)) {
		//prints correct usage
		std::cout << "Usage:\n";
		std::cout << "   ./qSim customers tellers period avgService [seed]";
		return EXIT_FAILURE;
	}

	// checks for valid input
	if (atoi(argv[1]) == 0 || atoi(argv[1]) == 0 || atoi(argv[2]) == 0 || atoi(argv[3]) == 0 || atoi(argv[4]) == 0) {
		std::cout << "Invalid input" << std::endl;
		return EXIT_FAILURE;
	}

	//determines if a seed is given
	if (argc > 4) {
		//sets seed
		seed = atoi(argv[5]);
		srand(seed);
	}
	// otherwise default
	else srand(time(NULL));

	// sets input
	numCustomers = atoi(argv[1]);
	numTellers = atoi(argv[2]);
	simulationTime = atof(argv[3]);
	avgServiceTime = atof(argv[4]);

	//std::cout << simulationTime << std::endl;


	// the event queue
	eventQueue *queue = new eventQueue(avgServiceTime);

	//creates all customers and inserts into eventQueue
	for (int i = 0; i < numCustomers; i++) {

		 float arrTime = simulationTime * (rand() / float(RAND_MAX)); //creates a random arrival time
		customerEvent *newCust = new customerEvent(arrTime); //creates a new customer with a random arrival time
		queue->InsertItem(newCust); //inserts customer into eventQueue
		//std::cout <<arrTime << std::endl;

	}

	//std::cout << queue->count() << std::endl;

	//createss tellers
	for(int i = 0; i < numTellers; i++) {
		float idleTime = rand() % 150;
		tellerEvent *newTeller = new tellerEvent(idleTime);
		queue->InsertItem(newTeller);
		//std::cout <<idleTime << std::endl;
	}

	//std::cout << queue->count() << std::endl;

	queue->print();

	eventQueue *tellerQueue = new eventQueue(0);

	int numCustomersServed = 0;
	float timeServicing = 0;
	//also print num tellers
	//print type of queuing
	float totalTimeInBank = 0;


	while(bankTime < simulationTime) {

		if (queue->head == NULL) {
			std::cout << "Empty Event queue" << std::endl;
			return EXIT_FAILURE;
		}

		if (!(queue->head->payload->isActive) && !(queue->head->payload->isTeller)) {
			//std::cout << "one printy boi" << std::endl;
			bankTime += queue->head->payload->eventTime;
			//std::cout << bankTime << std::endl;
			tellerQueue->InsertItem(queue->head->payload);
			//std::cout <<tellerQueue->count() << std::endl;
			queue->removeItem(queue);
			//std::cout << queue->count() << std::endl;
		}


		else if ((queue->head->payload->isActive) && !(queue->head->payload->isTeller)) {
			bankTime += queue->head->payload->eventTime;
			numCustomersServed++;
			float arr = static_cast<customerEvent*>(queue->head->payload)->arrivalTime;
			totalTimeInBank += (bankTime - arr);

			std::cout << totalTimeInBank << std::endl;

			bankTime = queue->head->next->payload->eventTime;
			queue->removeItem(queue);

		}

		else if(queue->head->payload->isTeller && !(tellerQueue->head == NULL)) {
			bankTime += queue->head->payload->eventTime;
			float serviceTime = 2 * avgServiceTime *rand() / float(RAND_MAX);
			timeServicing+= serviceTime;
			queue->head->payload->eventTime = serviceTime;
			queue->InsertItem(queue->head->payload);
			queue->removeItem(queue);
			tellerQueue->head->payload->eventTime = serviceTime;
			queue->InsertItem(tellerQueue->head->payload);
			tellerQueue->removeItem(tellerQueue);

		}
		else if (queue->head->payload->isTeller && (tellerQueue->head == NULL)) {
			bankTime += queue->head->payload->eventTime;
			float idleTime = rand() % 150;
			queue->head->payload->eventTime = idleTime;
			queue->InsertItem(queue->head->payload);
			queue->removeItem(queue);
		}
	}


	std::cout << "Simulation Statistics" << std::endl;
	std::cout << "Number of customers served:" << numCustomers << std::endl;
	std::cout << "Total Service Time: " << timeServicing << std::endl;
	std::cout << "Average time is bank: " << (totalTimeInBank /numCustomers) << std:: endl;


	std::cout << "You made it to the end" << std::endl;
}

