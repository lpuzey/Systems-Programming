/*
 * tellerQueue.h
 *
 *  Created on: Feb 16, 2018
 *      Author: lpuzey
 */

#ifndef TELLERQUEUE_H_
#define TELLERQUEUE_H_
#include "eventQueue.h"


namespace std {

//function prototypes and variable declerations
class tellerQueue: public eventQueue {
public:
	tellerQueue(float avgSerivceTime);
	virtual ~tellerQueue();
	void InsertItem();
};

} /* namespace std */

#endif /* TELLERQUEUE_H_ */
