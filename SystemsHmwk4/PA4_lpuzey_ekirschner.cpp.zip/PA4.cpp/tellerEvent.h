/*
 * tellerEvent.h
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#ifndef TELLEREVENT_H_
#define TELLEREVENT_H_

#include"Event.h"

//function prototypes and variable declerations
class tellerEvent: public Event{
public:
	tellerEvent(float eventTime); // constructor
	virtual ~tellerEvent(); // destructor
};

#endif /* TELLEREVENT_H_ */
