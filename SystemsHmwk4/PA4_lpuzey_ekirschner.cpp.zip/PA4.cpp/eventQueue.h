/*
 * eventQueue.h
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#ifndef EVENTQUEUE_H_
#define EVENTQUEUE_H_

#include <cstdio>
#include <cstdlib>

#include "Event.h"

//function prototypes and variable declerations
class eventQueue {
public:
	void InsertItem (Event *item); // inserts Events into the eventQueue
	void removeItem (eventQueue *item); // removes Events from the eventQueue
	eventQueue(float avgServiceTime); // constructor
	~eventQueue(); // destructor
	int count();
	void print();

	float avgServiceTime; // used to generate random service times
	class listItem;
	listItem *head;

	void printLastItems(listItem *p);

	class listItem { // an internal class
	public:

		Event *payload;
		listItem *next;

	//inline listItem(Event *item) : payload(item), next(NULL) {};
		listItem(Event* item){
			payload=item;
			next=NULL;
		}
	};	// class listItem

};



#endif /* EVENTQUEUE_H_ */
