/*
 * eventQueue.cpp
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#include <cstdio>
#include <iostream>
#include <cstdlib>

#include "eventQueue.h"

/**
 *@Param avgServiceTime
 */
eventQueue::eventQueue(float avgServiceTime) {
	head = NULL; // pointer to begining of queue
	this->avgServiceTime = avgServiceTime; //everge service time per interaction
}

/**
 *
 */
eventQueue::~eventQueue() {
	listItem *p = head;

	//deletes each item in event queue
	//while not head
	while (!p) {
		listItem *q = p -> next; //copies next
		delete p;
		p = q;
	}

	return;
}

/**
 * @Param *itemValue event being inserted into the queue
 */
void eventQueue::InsertItem(Event *itemValue){
	Event *e = itemValue;
	listItem *p = new listItem(e);

	if (!head) {
		head = p;
		return;
	}

	else if (itemValue->eventTime < head -> payload->eventTime) {
		p -> next = head;
		head = p;
	}

	else {
		listItem *q = head;
		while ((q -> next) && (q -> next -> payload->eventTime < itemValue->eventTime))
			q = q -> next;
		p -> next = q -> next;
		q -> next = p;
	}
}

/**
 * @Param *itemValue item being removed from queue
 */
void eventQueue::removeItem (eventQueue *itemValue){

	head = itemValue->head->next;  // sets head of this to next
	//itemValue->~Event(); // deletes the event

}

int eventQueue::count(){
	listItem *p = head;

	int count = 0;
	if (!head) {
		return 0;
	}

	else {
		count = 1;
		while(p->next){
			count++;
			p = p->next;
		}
		return count;
	}
}

void eventQueue::print(){
	listItem *p = head;

	if (!head) {
		return;
	}

	else {
		while(p->next){
			std::cout << p->payload->eventTime << std::endl;
			p = p->next;
		}
	}
}
