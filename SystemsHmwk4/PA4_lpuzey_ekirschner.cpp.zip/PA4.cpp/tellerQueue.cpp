/*
 * tellerQueue.cpp
 *
 *  Created on: Feb 16, 2018
 *      Author: lpuzey
 */

#include<iostream>
#include<cstdlib>

#include "tellerQueue.h"
#include"eventQueue.h"
#include"Event.h"

namespace std {

/**tellerQueue constructor
 * @Param event avgServiceTime average time it takes for a customer to be served
 */
tellerQueue::tellerQueue(float avgServiceTime):eventQueue(avgServiceTime) { }

/**tellerQueue deconstructor
 *will delete anything in the constructor
 */
tellerQueue::~tellerQueue() {

	}

}

//void eventQueue::InsertItem(Event *itemValue){
//	Event *e = itemValue;
//	listItem *p = new listItem(e);
//
//	if (!head) {
//		head = p;
//		return;
//	}
//
//	else if (itemValue < head -> payload) {
//		p -> next = head;
//		head = p;
//	}
//
//	else {
//		listItem *q = head;
//		while ((q -> next) && (q -> next -> payload < itemValue))
//			q = q -> next;
//		p -> next = q -> next;
//		q -> next = p;
//	}
//}
