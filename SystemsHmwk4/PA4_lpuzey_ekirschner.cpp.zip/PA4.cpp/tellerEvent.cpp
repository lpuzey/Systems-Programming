/*
 * tellerEvent.cpp
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#include "tellerEvent.h"

/**tellerEvent constructor
 * @Param eventTime time of event occurring
 */
tellerEvent::tellerEvent(float eventTime):Event(eventTime) {
	isTeller = true;
}

/**tellerEvent deconstructor
 *will delete anything in the constructor
 */
tellerEvent::~tellerEvent(){ }
