/*
 * Event.cpp
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */
#include<iostream>
#include "Event.h"

/**Event constructor
 * @Param eventTime time of event
 */
Event::Event(unsigned int eventTime){
	this->eventTime = eventTime;
	isActive = false;
	isTeller = false;
}

/**Event deconstructor
 *will delete anything in the constructor
 */
Event::~Event() {
	delete this;
}

float Event::action() {
	return 0;
}
