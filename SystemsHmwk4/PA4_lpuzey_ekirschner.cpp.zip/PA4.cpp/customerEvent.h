/*
 * customerEvent.h
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#ifndef CUSTOMEREVENT_H_
#define CUSTOMEREVENT_H_

#include "Event.h"

//function prototypes and variable declerations
class customerEvent: public Event{
public:
	customerEvent(float arrivalTime); // constructor
	virtual ~customerEvent(); // destructor
	float arrivalTime; //time customer arrives at the bank
	float action();
};


#endif /* CUSTOMEREVENT_H_ */
