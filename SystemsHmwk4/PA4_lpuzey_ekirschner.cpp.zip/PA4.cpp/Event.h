/*
 * Event.h
 *
 *  Created on: Feb 09, 2018
 *      Author: Linda Puzey & Elizabeth Kirschner
 */

#ifndef EVENT_H_
#define EVENT_H_

class Event {
public:
	Event(unsigned eventTime); // constructor
	virtual ~Event(); // destructor
	float eventTime; // time of event
	bool isActive; // true if event is participating in a service
	bool isTeller;//true if the event belongs to that of a teller
	virtual float action();
};

#endif /* EVENT_H_ */

