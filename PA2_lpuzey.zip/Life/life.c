/* Game of Life -- Linda Puzey
*/

#include <stdio.h>
#include <stdlib.h>
#include "twoD.h"

/** Main function.
 * @param argc Number of words on the command line.
 * @param argv Array of pointers to character strings containing the
 *    words on the command line.
 * @return 0 if success, 1 if invalid command line or unable to open file.
 *
 */
int main(int argc, char **argv) {
	printf("Game of Life\n");

	char *inputFileName; // Name of file containing initial grid
	FILE *input; // Stream descriptor for file containing initial grid
	int rows; // Number of rows in the grid
	int columns; // Number of columns in the grid
	int gens; // Number of generations to produce
	int doPrint; // 1 if user wants to print each generation, 0 if not
	int doPause; // 1 if user wants to pause after each generation, 0 if not
	char **gridA; // A 2D array to hold the pattern
	int maxColumns;// The maximum number of columns in the input file
	int maxRows;// The maximum number of rows in the input file
	char **gridB;//A 2D array to hold the pattern
	char **gridC;//A 2D array to hold the pattern

	// See if there are the right number of arguments on the command line
	if ((argc < 5) || (argc > 7)) {
		// If not, tell the user what to enter.
		printf("Usage:\n");
		printf("  ./life rows columns generations inputFile [print] [pause]\n");
		return EXIT_FAILURE;
	}

	/* Save the command-line arguments.
	   Also need to check if print and/or pause arguments were entered,
	   and if so, what they were.
	   A switch statement might be handy here.
	*/
	rows = atoi(argv[1]); // Convert from character string to integer.
	columns = atoi(argv[2]);
	gens = atoi(argv[3]);
	inputFileName = argv[4];

//Testing to see how many arguments the user inputs
//if there are greater than 6 arguments and the first part is a y, doPrint is 1 (for on)
//else doPrint is 0
	if(argc >= 6){
		if(argv[5][0] == 'y'){
			doPrint = 1;
		}
		else{
			doPrint = 0;
		}
	}
	else{
		doPrint = 0;
	}

//Testing if the agruments is greater than or equal to 7
//if there are greater than 7 arguments and the first part is a y, doPause is equal to 1
//else it is equal to 0
	if(argc >= 7){
		if(argv[6][0] == 'y'){
					doPause = 1;
				}
				else{
					doPause = 0;
				}
			}
	else{
		doPause = 0;
	}

	/* Here is how you would allocate an array to hold the grid.
	*/
	// You should check that it succeeded.
	gridA = make2Dchar(rows, columns);

//testing if the array was stored correctly
//It will print an error message and return a failure if it null
	if(gridA == NULL){
		printf("Unable to allocate memory for gridA");
		return EXIT_FAILURE;
	}

	gridB = make2Dchar(rows, columns);

//testing if the array was stored correctly
//It will print an error message and return a failure if it null
	if(gridB == NULL){
			printf("Unable to allocate memory for gridB");
			return EXIT_FAILURE;
		}

	gridC = make2Dchar(rows, columns);

//testing if the array was stored correctly
//It will print an error message and return a failure if it null
	if(gridC == NULL){
			printf("Unable to allocate memory for gridC");
			return EXIT_FAILURE;
		}

	/* Eventually, need to try to open the input file.
	*/
	input = fopen(inputFileName, "r");
	if (!input) {
		printf("Unable to open input file: %s\n", inputFileName);
		return EXIT_FAILURE;
	}

	/*Once opened, you can read from the file one character at a time with fgetc().
	 * You can read one line at a time using fgets().
	 * You can read from standard input (the keyboard) with getchar().
	*/

//filling each array with o's
	populate(gridA,rows,columns);
	populate(gridB,rows,columns);
	populate(gridC,rows,columns);

//testing the return of xPop and actually returning that so I don't have a conflicting return type
	if(xPop(gridA,input,rows,columns,&maxRows,&maxColumns)== EXIT_FAILURE){
		return EXIT_FAILURE;
	}

//centers the input file on the grid
	center(gridA, gridB, rows, columns, maxRows,maxColumns);

//filling each array with o's
	populate(gridA,rows,columns);

//printing the values in the arrays
	printGrid(gridB,rows,columns);


	int gen; //generation that the user inputs
	char** next; //array with the rules of the game applied
	char** old1; //first array
	char** old2; // second array
	char** temp; //stand in array to fix pointer problem

	next = gridC;
	old1 = gridB;
	old2 = gridA;


// gen>=0 && gen<gens, increases gen until it is greater than gens
	for(gen=0;gen < gens;gen++){
		if(doPrint){
			printf("Generation %d\n",(gen + 1));
		}
		nextGen(next, old1,rows,columns);
//testing if doPrint is equal to 1
//if it is, it will print every single generation
		if(doPrint == 1){
			printGrid(next,rows, columns);
		}
//testing if doPause is equal to 1
//if it is if uses a scanf to advance to the next generation
		if(doPause == 1){
			char c;
			printf("Press any key to continue\n");
			c = scanf("%c");
		}
//Testing to see if the previous generation is the same as the next one
//if it is, it prints an error message and exits
		if(compare(next,old1,rows,columns) == 1){
			printf("generation %d matches generation %d \n",(gen+1),gen);
			return EXIT_FAILURE;
		}
//Testing to see if two generations back is the same as the next one
//if is is, it prints an error message and exits
		if(compare(next,old2,rows,columns) == 1){
			printf("generation %d matches generation %d \n",(gen+1),(gen-1));
			return EXIT_FAILURE;
		}
		temp = old2;
		old2 = old1;
		old1 = next;
		next = temp;
		/*printf("old1\n");
		printGrid(old1, rows, columns);
		printf("old2\n");
		printGrid(old2, rows, columns);
		printf("next\n");
		printGrid(next, rows, columns);*/
	}
//Testing if doPrint is 0
//if it is, then it will print only print out the last generation
	if(doPrint == 0){
		printf("Generation %d\n",gen);
		printGrid(old1,rows, columns);

	}
	printf("Successfully generated %d generations\n", gen);
	return EXIT_SUCCESS;
}

/** Populate function.
 * @param gridA, 2D array of characters
 * @param rows, inputed rows by the user
 * @param columns, inputed columns by the user
 * populates the array with o's
 */
	void populate(char** gridA,int rows, int columns){
		int i;//represents the rows
		int j;//represents the columns

// i>=0 && i<rows, increases i until it is greater than rows
		for(i=0;i<rows;i++){
// j>=0 && j<rows, increases j until it is greater than columns
			for(j=0;j<columns;j++){
				gridA[i][j] = 'o';
			}
		}
	}

/** PrintGrid function.
* @param gridA, 2D array of characters
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* prints the 2D array with all o's
*/
	void printGrid(char** gridA,int rows, int columns){
		int i;//represents the rows
		int j;//represents the columns

// i>=0 && i<rows, increases i until it is greater than rows
				for(i=0;i<rows;i++){
// j>=0 && j<rows, increases j until it is greater than columns
					for(j=0;j<columns;j++){
						printf("%c",gridA[i][j]);
					}
				printf("\n");}
	}

/** xPop function.
* @param gridA, 2D array of characters
* @param input, the user's input file
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* @param maxRows, the maximum number of rows in the input file
* @param maxColumns, the maximum number of columns in the input file
* goes through the input file
* prints x's into your array
* calculates maxRows and maxColumns, which is used to center it later
* @return it will return if a success of failure
*/
	int xPop(char** gridA,FILE* input,int rows, int columns,int* maxRows,int* maxColumns){
				int i;//represents the rows
				int j;//represents the columns
				char r;//stand in character for input file
				*maxRows = 0;
				*maxColumns = 0;
				i = 0;
				j = 0;
				r = NULL;
				do{
						r = fgetc(input);
//testing if the input character is a x or o
						if((r == 'x')||(r == 'o')){
//testing if i is greater than or equal to the row size and
//testing if the j is greater than or euqal to the column size
							if((i >= rows)||(j >= columns)){
								printf("Rows or Columns was too small for your input file\n");
								return EXIT_FAILURE;
							}
//testing if j is greater than the max columns
// if it is than j is equal to that
							if(j > *maxColumns){
								*maxColumns = j;
							}
//testing if i is greater than the max rows
// if it is than i is equal to that
							if(i > *maxRows){
								*maxRows = i;
							}
							gridA[i][j++]= r;
						}
//testing if the input character is an indent line
//if it is then it will incriment i and set j to 0
						else if(r == '\n'){
							i++;
							j=0;
						}
//testing if the input character is not equal to the end of file
//if it is then it will print an error message and exit
						else if(r != EOF){
							printf("Error with input\n");
							return EXIT_FAILURE;
						}

				}while(r != EOF);
				//printf("MC%d,MR%d\n",*maxColumns, *maxRows);
				return EXIT_SUCCESS;
			}

/** Center function.
* @param gridA, 2D array of characters
* @param gridA, 2D array of characters
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* @param maxRows, the maximum number of rows in the input file
* @param maxColumns, the maximum number of columns in the input file
* uses maxRows and maxColumns to center x's in the array
*/
	void center(char** gridA, char** gridB, int rows, int columns, int maxRows,int maxColumns){

		int cOffset;//variable for where the x's and o's should go with the algorithm applied
		int rOffset;//variable for where the x's and o's should go with the algorithm applied
		int i;//represents rows
		int j;//represents columns

		cOffset =((columns - (maxColumns +1))/2);
		rOffset =((rows - (maxRows+1))/2);

// i>=0 && i<=maxRows, increases i until it is greater than maxrows
		for(i=0;i<=maxRows;i++){
// j>=0 && j<=maxColumns, increases i until it is greater than maxcolumns
			for(j=0;j<=maxColumns;j++){
				gridB[i+rOffset][j+cOffset] = gridA[i][j];
			}
		}
	}
/** Compare function.
* @param new, 2D array of characters
* @param old, 2D array of characters
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* checks if the two inputed arrays are equal to each other
* @return 1 is if they are equal to each other and 0 if not
*/
	int compare(char** new, char** old, int rows, int columns){
		int i;//represents rows
		int j;//represents columns
		int equal;//1 for equal and 0 if not equal
		equal = 1;

// i>=0 && i<=rows, increases i until it is greater than rows
		for(i=0;i<rows;i++){
// j>=0 && j<=columns, increases j until it is greater than columns
			for(j=0;j<columns;j++){
//testing if the new and old functions are not the same. If they aren't then equals is 0
						if(new[i][j] != old[i][j]){
							equal = 0;
						}
				}
		}
		return equal;
	}

/** CalcNeighbors function.
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* @param checkR, used to check if the cell is alive
* @param checkC, used to check if the cell is alive
* @param old, 2D array of characters
* calculates if a cell is alive
* calculates how many neighbors a cell has
* applies the rules of the game of life
* @return give you the o or x cell back
*/

	char calcNeighbors(int rows, int columns,int checkR,int checkC,char** old){
		int i;//represents rows
		int j;//represents columns
		int neighbors;//how many neighbors a cell has
		int alive;//if the cell is alive. 1 for yes. 0 for no.
		int startR;//number for the start of the row
		int startC;//number for the start of the column
		int endR;//number for the end of the row
		int endC;//number for the end of the column
		char cell;//represents a cell x or o

		startR = checkR -1;
		checkR = startR +1;
		endR = checkR +1;
		startC = checkC -1;
		checkC = startC +1;
		endC = checkC +1;

//testing if the start of the row is less than 0
//if it is then the start of the row equals 0
		if(startR < 0){
			startR = 0;
		}
//testing if the end of the row is greater than the rows minus 1
//if it is then the end of the row is rows minus 1
		if(endR > (rows-1)){
			endR = (rows-1);
		}
//testing if the start of the column is less than 0
//if it is then the start of the column equals 0
		if(startC < 0){
			startC = 0;
		}
//testing if the end of the column is greater than the column minus 1
//if it is then the end of the column equals column - 1
		if(endC > (columns -1)){
			endC = (columns -1);
		}

		neighbors = 0;
		alive = 0;
// i>=startR && i<=endR, increases i until it is greater than endR
		for(i=startR;i<= endR;i++){
// j>=startC && j<=endC, increases i until it is greater than endC
				for(j=startC;j<=endC;j++){
//Testing if the cell is equal to x
					if(old[i][j] == 'x'){
//Testing if i is equal to checkR and j is equal to checkC
//if it is true alive will equal 1
//else it will increase neighbors
						if((i == checkR) &&(j == checkC)){
							alive = 1;
						}
						else{
							neighbors++;
						}
					}
				}
		}
		cell = 'o';

//Testing if alive is equal to 1
		if(alive == 1){
//Testing if neighbors is equal to 2 or neighbors is equal to 3
//if that is true than the cell becomes an x
			if((neighbors == 2) ||(neighbors == 3)){
				cell = 'x';
			}
		}
//Testing if the neighbors is equal to 3
//if that is true than the cell becomes an x
		else if(neighbors == 3){
				cell = 'x';
			}
		return cell;

	}

/** NextGen function.
* @param new, 2D array of characters
* @param old, 2D array of characters
* @param rows, inputed rows by the user
* @param columns, inputed columns by the user
* uses calcNeighbors() and uses it to calculate the next generation
*/
	void nextGen(char** new,char** old,int rows,int columns){
			int i;//represents the rows
			int j;//represents the columns
			char c;//represents a character x or o

// i>=0 && i<=rows, increases i until it is greater than rows
			for(i=0;i<rows;i++){
// j>=0 && j<=columns, increases j until it is greater than columns
						for(j=0;j<columns;j++){
							c = calcNeighbors(rows, columns, i, j, old);
//testing if x is equal to the character x
//if it's true then the new array is equal to c
							if (c == 'x'){
								new[i][j]= c;
							}
				}
			}
		}
